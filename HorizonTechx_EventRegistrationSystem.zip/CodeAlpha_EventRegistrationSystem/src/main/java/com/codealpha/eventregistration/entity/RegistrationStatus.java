package com.codealpha.eventregistration.entity;

public enum RegistrationStatus {
    CONFIRMED,
    CANCELLED
}
