package com.codealpha.eventregistration.controller;

import com.codealpha.eventregistration.dto.RegistrationRequest;
import com.codealpha.eventregistration.dto.RegistrationResponse;
import com.codealpha.eventregistration.service.RegistrationService;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/registrations")
public class RegistrationController {

    private final RegistrationService registrationService;

    public RegistrationController(RegistrationService registrationService) {
        this.registrationService = registrationService;
    }

    // Submit a registration form for an event
    @PostMapping
    public ResponseEntity<RegistrationResponse> register(@Valid @RequestBody RegistrationRequest request) {
        return ResponseEntity.status(HttpStatus.CREATED).body(registrationService.register(request));
    }

    // Cancel a registration
    @PutMapping("/{id}/cancel")
    public ResponseEntity<RegistrationResponse> cancel(@PathVariable Long id) {
        return ResponseEntity.ok(registrationService.cancel(id));
    }

    // View a user's registrations ("manage my registrations")
    @GetMapping("/user/{userId}")
    public ResponseEntity<List<RegistrationResponse>> getByUser(@PathVariable Long userId) {
        return ResponseEntity.ok(registrationService.getByUser(userId));
    }

    // View all registrations for a given event (organizer view)
    @GetMapping("/event/{eventId}")
    public ResponseEntity<List<RegistrationResponse>> getByEvent(@PathVariable Long eventId) {
        return ResponseEntity.ok(registrationService.getByEvent(eventId));
    }
}
