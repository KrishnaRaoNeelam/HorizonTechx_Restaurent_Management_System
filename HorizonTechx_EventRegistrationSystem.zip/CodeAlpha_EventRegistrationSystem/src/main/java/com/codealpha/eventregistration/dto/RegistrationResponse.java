package com.codealpha.eventregistration.dto;

import com.codealpha.eventregistration.entity.RegistrationStatus;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class RegistrationResponse {
    private Long id;
    private Long userId;
    private String userName;
    private Long eventId;
    private String eventTitle;
    private RegistrationStatus status;
    private LocalDateTime registeredAt;
}
