package com.codealpha.eventregistration.service;

import com.codealpha.eventregistration.dto.UserRegisterRequest;
import com.codealpha.eventregistration.entity.Role;
import com.codealpha.eventregistration.entity.User;
import com.codealpha.eventregistration.exception.BadRequestException;
import com.codealpha.eventregistration.exception.ResourceNotFoundException;
import com.codealpha.eventregistration.repository.UserRepository;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class UserService {

    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;

    public UserService(UserRepository userRepository, PasswordEncoder passwordEncoder) {
        this.userRepository = userRepository;
        this.passwordEncoder = passwordEncoder;
    }

    public User register(UserRegisterRequest request) {
        if (userRepository.existsByEmail(request.getEmail())) {
            throw new BadRequestException("An account with this email already exists");
        }

        User user = new User();
        user.setFullName(request.getFullName());
        user.setEmail(request.getEmail());
        user.setPassword(passwordEncoder.encode(request.getPassword()));

        try {
            user.setRole(request.getRole() != null && !request.getRole().isBlank()
                    ? Role.valueOf(request.getRole().toUpperCase())
                    : Role.ATTENDEE);
        } catch (IllegalArgumentException ex) {
            throw new BadRequestException("role must be ATTENDEE or ORGANIZER");
        }

        return userRepository.save(user);
    }

    public User getById(Long id) {
        return userRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("User not found with id: " + id));
    }

    public List<User> getAll() {
        return userRepository.findAll();
    }
}
