package com.codealpha.eventregistration.dto;

import jakarta.validation.constraints.NotNull;
import lombok.Data;

@Data
public class RegistrationRequest {

    @NotNull
    private Long userId;

    @NotNull
    private Long eventId;
}
