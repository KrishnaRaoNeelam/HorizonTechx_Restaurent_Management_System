package com.codealpha.eventregistration.entity;

public enum Role {
    ATTENDEE,
    ORGANIZER
}
