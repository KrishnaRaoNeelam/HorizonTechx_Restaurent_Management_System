package com.codealpha.eventregistration.dto;

import jakarta.validation.constraints.Future;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;
import lombok.Data;

import java.time.LocalDateTime;

@Data
public class EventRequest {

    @NotBlank
    private String title;

    private String description;

    @NotBlank
    private String location;

    @NotNull
    @Future(message = "eventDate must be in the future")
    private LocalDateTime eventDate;

    @NotNull
    @Positive
    private Integer capacity;

    // organizer's user id
    @NotNull
    private Long organizerId;
}
