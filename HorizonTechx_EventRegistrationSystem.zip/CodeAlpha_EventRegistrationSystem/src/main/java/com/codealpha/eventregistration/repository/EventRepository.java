package com.codealpha.eventregistration.repository;

import com.codealpha.eventregistration.entity.Event;
import org.springframework.data.jpa.repository.JpaRepository;

import java.time.LocalDateTime;
import java.util.List;

public interface EventRepository extends JpaRepository<Event, Long> {
    List<Event> findByEventDateAfterOrderByEventDateAsc(LocalDateTime now);
    List<Event> findByOrganizerId(Long organizerId);
}
