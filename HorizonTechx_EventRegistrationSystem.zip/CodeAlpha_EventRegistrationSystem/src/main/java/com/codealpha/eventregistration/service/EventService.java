package com.codealpha.eventregistration.service;

import com.codealpha.eventregistration.dto.EventRequest;
import com.codealpha.eventregistration.dto.EventResponse;
import com.codealpha.eventregistration.entity.Event;
import com.codealpha.eventregistration.entity.RegistrationStatus;
import com.codealpha.eventregistration.entity.User;
import com.codealpha.eventregistration.exception.ResourceNotFoundException;
import com.codealpha.eventregistration.repository.EventRepository;
import com.codealpha.eventregistration.repository.RegistrationRepository;
import com.codealpha.eventregistration.repository.UserRepository;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class EventService {

    private final EventRepository eventRepository;
    private final UserRepository userRepository;
    private final RegistrationRepository registrationRepository;

    public EventService(EventRepository eventRepository, UserRepository userRepository,
                         RegistrationRepository registrationRepository) {
        this.eventRepository = eventRepository;
        this.userRepository = userRepository;
        this.registrationRepository = registrationRepository;
    }

    public EventResponse createEvent(EventRequest request) {
        User organizer = userRepository.findById(request.getOrganizerId())
                .orElseThrow(() -> new ResourceNotFoundException("Organizer not found with id: " + request.getOrganizerId()));

        Event event = new Event();
        event.setTitle(request.getTitle());
        event.setDescription(request.getDescription());
        event.setLocation(request.getLocation());
        event.setEventDate(request.getEventDate());
        event.setCapacity(request.getCapacity());
        event.setOrganizer(organizer);

        Event saved = eventRepository.save(event);
        return toResponse(saved);
    }

    public List<EventResponse> getUpcomingEvents() {
        return eventRepository.findByEventDateAfterOrderByEventDateAsc(LocalDateTime.now()).stream()
                .map(this::toResponse)
                .collect(Collectors.toList());
    }

    public List<EventResponse> getAllEvents() {
        return eventRepository.findAll().stream()
                .map(this::toResponse)
                .collect(Collectors.toList());
    }

    public EventResponse getEventById(Long id) {
        Event event = eventRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Event not found with id: " + id));
        return toResponse(event);
    }

    public void deleteEvent(Long id) {
        if (!eventRepository.existsById(id)) {
            throw new ResourceNotFoundException("Event not found with id: " + id);
        }
        eventRepository.deleteById(id);
    }

    private EventResponse toResponse(Event event) {
        long confirmed = registrationRepository.countByEventIdAndStatus(event.getId(), RegistrationStatus.CONFIRMED);
        int remaining = (int) (event.getCapacity() - confirmed);
        return new EventResponse(
                event.getId(),
                event.getTitle(),
                event.getDescription(),
                event.getLocation(),
                event.getEventDate(),
                event.getCapacity(),
                confirmed,
                Math.max(remaining, 0),
                event.getOrganizer() != null ? event.getOrganizer().getFullName() : null
        );
    }
}
