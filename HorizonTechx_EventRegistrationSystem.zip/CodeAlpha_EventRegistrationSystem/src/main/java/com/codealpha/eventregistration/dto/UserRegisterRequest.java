package com.codealpha.eventregistration.dto;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import lombok.Data;

@Data
public class UserRegisterRequest {

    @NotBlank
    private String fullName;

    @NotBlank @Email
    private String email;

    @NotBlank @Size(min = 6, message = "password must be at least 6 characters")
    private String password;

    // "ATTENDEE" or "ORGANIZER" - defaults to ATTENDEE if blank
    private String role;
}
