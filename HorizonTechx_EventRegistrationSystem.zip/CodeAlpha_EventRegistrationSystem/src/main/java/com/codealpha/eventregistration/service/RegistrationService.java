package com.codealpha.eventregistration.service;

import com.codealpha.eventregistration.dto.RegistrationRequest;
import com.codealpha.eventregistration.dto.RegistrationResponse;
import com.codealpha.eventregistration.entity.*;
import com.codealpha.eventregistration.exception.BadRequestException;
import com.codealpha.eventregistration.exception.ResourceNotFoundException;
import com.codealpha.eventregistration.repository.EventRepository;
import com.codealpha.eventregistration.repository.RegistrationRepository;
import com.codealpha.eventregistration.repository.UserRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class RegistrationService {

    private final RegistrationRepository registrationRepository;
    private final UserRepository userRepository;
    private final EventRepository eventRepository;

    public RegistrationService(RegistrationRepository registrationRepository, UserRepository userRepository,
                                EventRepository eventRepository) {
        this.registrationRepository = registrationRepository;
        this.userRepository = userRepository;
        this.eventRepository = eventRepository;
    }

    @Transactional
    public RegistrationResponse register(RegistrationRequest request) {
        User user = userRepository.findById(request.getUserId())
                .orElseThrow(() -> new ResourceNotFoundException("User not found with id: " + request.getUserId()));
        Event event = eventRepository.findById(request.getEventId())
                .orElseThrow(() -> new ResourceNotFoundException("Event not found with id: " + request.getEventId()));

        registrationRepository.findByUserIdAndEventId(user.getId(), event.getId())
                .ifPresent(existing -> {
                    if (existing.getStatus() == RegistrationStatus.CONFIRMED) {
                        throw new BadRequestException("User is already registered for this event");
                    }
                });

        long confirmedCount = registrationRepository.countByEventIdAndStatus(event.getId(), RegistrationStatus.CONFIRMED);
        if (confirmedCount >= event.getCapacity()) {
            throw new BadRequestException("Event is full. No spots remaining for: " + event.getTitle());
        }

        Registration registration = registrationRepository.findByUserIdAndEventId(user.getId(), event.getId())
                .orElse(new Registration());
        registration.setUser(user);
        registration.setEvent(event);
        registration.setStatus(RegistrationStatus.CONFIRMED);

        Registration saved = registrationRepository.save(registration);
        return toResponse(saved);
    }

    @Transactional
    public RegistrationResponse cancel(Long registrationId) {
        Registration registration = registrationRepository.findById(registrationId)
                .orElseThrow(() -> new ResourceNotFoundException("Registration not found with id: " + registrationId));
        registration.setStatus(RegistrationStatus.CANCELLED);
        Registration saved = registrationRepository.save(registration);
        return toResponse(saved);
    }

    public List<RegistrationResponse> getByUser(Long userId) {
        return registrationRepository.findByUserId(userId).stream()
                .map(this::toResponse)
                .collect(Collectors.toList());
    }

    public List<RegistrationResponse> getByEvent(Long eventId) {
        return registrationRepository.findByEventId(eventId).stream()
                .map(this::toResponse)
                .collect(Collectors.toList());
    }

    private RegistrationResponse toResponse(Registration r) {
        return new RegistrationResponse(
                r.getId(),
                r.getUser().getId(),
                r.getUser().getFullName(),
                r.getEvent().getId(),
                r.getEvent().getTitle(),
                r.getStatus(),
                r.getRegisteredAt()
        );
    }
}
