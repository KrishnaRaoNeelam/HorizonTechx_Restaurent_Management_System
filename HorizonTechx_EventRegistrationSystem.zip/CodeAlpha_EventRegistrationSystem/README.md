# CodeAlpha_EventRegistrationSystem

Backend Development Internship — Task 2: Event Registration System
Built with **Java 17 + Spring Boot 3 + Spring Data JPA + MySQL + Spring Security (for password hashing)**.

## Features
- **Users**: register as `ATTENDEE` or `ORGANIZER`, passwords stored as BCrypt hashes.
- **Events**: organizers create events with title, description, location, date, and capacity.
- View event list (upcoming only) and full event details, including live seats-remaining count.
- **Registrations**: attendees register for events; the system enforces:
  - no duplicate active registration for the same user + event,
  - no registration once an event's capacity is reached.
- Users can view and cancel their own registrations ("manage my registrations").
- Organizers can view the full registrant list for their event.

## Tech Stack
- Java 17, Spring Boot 3.3
- Spring Web, Spring Data JPA, Spring Validation, Spring Security (BCrypt only — see note below)
- MySQL 8, Maven, Lombok

## Entity Relationships
```
User (1) ──< Registration >── (1) Event
User (1) ──< Event    (organizer relationship)
```
- `User` ⇄ `Registration`: one user has many registrations.
- `Event` ⇄ `Registration`: one event has many registrations.
- `User` ⇄ `Event`: one user (organizer) creates many events.
- Unique constraint on `(user_id, event_id)` in `registration` prevents duplicate signups.

## Setup

1. **Install MySQL**, ensure it's running.
2. Edit `src/main/resources/application.properties` with your credentials:
   ```properties
   spring.datasource.url=jdbc:mysql://localhost:3306/event_registration_db?createDatabaseIfNotExist=true&useSSL=false&serverTimezone=UTC
   spring.datasource.username=root
   spring.datasource.password=your_mysql_password
   ```
3. Build & run (runs on **port 8081** by default so it can run alongside the URL Shortener project):
   ```bash
   mvn clean install
   mvn spring-boot:run
   ```

## API Reference

### Users
| Method | Endpoint | Description |
|---|---|---|
| POST | `/api/users/register` | Register a new user. Body: `{ "fullName", "email", "password", "role": "ATTENDEE"|"ORGANIZER" }` |
| GET | `/api/users/{id}` | Get user by id |
| GET | `/api/users` | List all users |

### Events
| Method | Endpoint | Description |
|---|---|---|
| POST | `/api/events` | Create event. Body: `{ "title", "description", "location", "eventDate", "capacity", "organizerId" }` |
| GET | `/api/events` | List **upcoming** events |
| GET | `/api/events/all` | List all events (past + upcoming) |
| GET | `/api/events/{id}` | Event details (with seats remaining) |
| DELETE | `/api/events/{id}` | Delete an event |

### Registrations
| Method | Endpoint | Description |
|---|---|---|
| POST | `/api/registrations` | Register for an event. Body: `{ "userId", "eventId" }` |
| PUT | `/api/registrations/{id}/cancel` | Cancel a registration |
| GET | `/api/registrations/user/{userId}` | View a user's registrations |
| GET | `/api/registrations/event/{eventId}` | View all registrants for an event (organizer view) |

## Example Flow (curl)
```bash
# 1. Register an organizer
curl -X POST http://localhost:8081/api/users/register \
  -H "Content-Type: application/json" \
  -d '{"fullName":"Alice Organizer","email":"alice@codealpha.tech","password":"secret123","role":"ORGANIZER"}'

# 2. Register an attendee
curl -X POST http://localhost:8081/api/users/register \
  -H "Content-Type: application/json" \
  -d '{"fullName":"Bob Attendee","email":"bob@codealpha.tech","password":"secret123"}'

# 3. Create an event (organizerId = 1)
curl -X POST http://localhost:8081/api/events \
  -H "Content-Type: application/json" \
  -d '{"title":"Spring Boot Workshop","description":"Hands-on session","location":"Hyderabad","eventDate":"2026-12-01T10:00:00","capacity":50,"organizerId":1}'

# 4. Attendee registers for the event (userId = 2, eventId = 1)
curl -X POST http://localhost:8081/api/registrations \
  -H "Content-Type: application/json" \
  -d '{"userId":2,"eventId":1}'

# 5. Cancel that registration (registrationId = 1)
curl -X PUT http://localhost:8081/api/registrations/1/cancel
```

## Project Structure
```
src/main/java/com/codealpha/eventregistration/
├── EventRegistrationApplication.java
├── config/SecurityConfig.java
├── controller/  UserController, EventController, RegistrationController
├── service/     UserService, EventService, RegistrationService
├── repository/  UserRepository, EventRepository, RegistrationRepository
├── entity/      User, Event, Registration, Role, RegistrationStatus
├── dto/         request/response objects
└── exception/   ResourceNotFoundException, BadRequestException, GlobalExceptionHandler
```

## Notes on Security
Spring Security is included **only to get BCrypt password hashing** for the `User` entity.
All API endpoints are left open (`permitAll()`) so the task list's core CRUD/relationship
requirements can be tested directly with curl/Postman without needing a login flow first.
Wiring up full authentication (JWT or session-based, with an organizer-only guard on
`POST /api/events`) is a natural "optional" extension mentioned in the task brief — the
`Role` enum and password hashing are already in place to build that on top.
